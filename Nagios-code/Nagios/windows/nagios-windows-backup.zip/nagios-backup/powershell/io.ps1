### calculate the io usage of the system ###

#$Counter = Get-Counter -Counter "\LogicalDisk(*)\Avg. Disk sec/Write"



#$counter | out-file -filepath C:\io_data1.txt

#$counter2 = Get-Content "C:\io_data1.txt" | Select-Object -Index 10 

#$total = $counter2  -replace '\s',''

$total = (Get-Counter '\LogicalDisk(*)\Avg. Disk sec/Write').CounterSamples.CookedValue[2]

#Write-Output("$total")

if($total -le 0.1111){
   Write-Output("ok - Usage of $total  io process ")
   exit 0
} elseif($total -ge 0.1112  -and $total -le  0.2112){

   Write-Output("WARNING - Usage of $total  io process ")
C:\Python\Python38-32\python.exe C:\Users\io.py
   exit 1
}
 elseif($total -ge 0.2113 ){

   Write-Output("CRITICAL - Usage of $total  io process ")
C:\Python\Python38-32\python.exe C:\Users\io.py
   exit 2
}
 else{
   Write-Output("UNKNOWN - Usage of $total  io process ")
   exit 3
}