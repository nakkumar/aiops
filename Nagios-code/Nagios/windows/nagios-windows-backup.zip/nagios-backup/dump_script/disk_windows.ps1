fsutil file createnew C:\big_file\big_file.txt 5368709120
