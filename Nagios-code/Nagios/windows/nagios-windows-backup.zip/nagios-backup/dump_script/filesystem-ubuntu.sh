#!/bin/bash

#stress-ng --hdd 5 --hdd-ops 100000
mkdir /tmp/test
fallocate -l 5G /tmp/test/big_5G_file.123
