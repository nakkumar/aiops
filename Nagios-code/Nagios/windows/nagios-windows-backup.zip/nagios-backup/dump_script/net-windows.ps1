Disable-NetAdapter -Name "WiFi" -Confirm:$false

Start-Sleep -s 120

Enable-NetAdapter -Name "WiFi" -Confirm:$false
