#$result = 1; foreach ($number in 1..2147483647) {$result = $result * $number};

fsutil file createnew C:\big_file\big_file.txt 5368709120
