#!/bin/bash

#dd if=/dev/zero of=/tmp/`date +%Y%m%d%H%M%S` bs=700M count=1 oflag=direct
#systemctl stop crond
#adduser arun
#mkdir /root/test
#stress-ng --vm 2 --vm-bytes 800M --timeout 75s
stress --vm 6 --timeout 150s
