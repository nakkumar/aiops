stress --io 4 --timeout 60s
