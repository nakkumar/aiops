ab -c 1000 -n 1000 -r -t 30 http://192.168.4.115/demo.php
