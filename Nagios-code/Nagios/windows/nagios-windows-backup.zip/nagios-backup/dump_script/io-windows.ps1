fsutil file createnew C:\big-file\big-file 19327352832

copy-item -path C:\big-file\big-file C:\copy\big-file

Start-Sleep -s 450

remove-item -path 'C:\copy\big-file'

remove-item -path 'C:\big-file\big-file'