mkdir /tmp/test
fallocate -l 12G /tmp/test/big_12G_file.123
