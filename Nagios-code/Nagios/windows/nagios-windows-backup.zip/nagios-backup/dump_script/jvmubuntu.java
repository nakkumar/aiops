//Java program to demonstrate the use of infinite for loop
//which prints an statement
public class jvmubuntu {
public static void main(String[] args) {
    //Using no condition in for loop
    for(;;){
        System.out.println("infinitive loop");
    }
}
}
