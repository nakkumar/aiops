#!/bin/bash

#dd if=/dev/zero of=/tmp/`date +%Y%m%d%H%M%S` bs=1200M count=1 oflag=direct
#mkdir /root/test
#systemctl stop cron
#stress-ng --vm 2 --vm-bytes 800M --timeout 75s
stress --vm 6 --timeout 150s
