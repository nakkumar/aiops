copy-Item -Path C:\big-file\test.txt -Destination C:\copy\test.txt

Start-Sleep -s 200

remove-item "C:\copy\test.txt"