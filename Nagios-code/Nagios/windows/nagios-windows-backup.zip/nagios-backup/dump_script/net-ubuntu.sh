#!/bin/bash

ifdown ens3

sleep 150

ifup ens3
