Stop-Service -Name apache
