#!/bin/bash

stress --cpu 8 -v --timeout 100s
