#!/bin/bash

ifdown eth0

sleep 150

ifup eth0
