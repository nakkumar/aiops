#!/bin/bash

systemctl stop apache2
