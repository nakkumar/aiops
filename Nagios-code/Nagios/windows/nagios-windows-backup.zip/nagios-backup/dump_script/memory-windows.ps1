
#1..50|%{$x=1}{[array]$x+=$x}
$mem_stress = "a" * 1000MB