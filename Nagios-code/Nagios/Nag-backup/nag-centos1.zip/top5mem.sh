#!/bin/bash

countWarnings=$(free -m | awk 'NR==2{printf "%.2f%%\t\t", $3*100/$2 }' | sed 's/%//g')
name=$(ps -eo comm --sort=-%mem | head -n 6 | tail -5 | awk  'BEGIN { ORS="," } { print }')

if (( ${countWarnings%%.*}<=60 )); then
                echo "OK - Usage of   ${countWarnings%%.*} % top 5 process --> $name "
                exit 0
        elif (( 61<=${countWarnings%%.*} && ${countWarnings%%.*}<=70 )); then
                echo "WARNING - Usage of  ${countWarnings%%.*} % top 5 process --> $name"
                exit 1
        elif (( 71<=${countWarnings%%.*} && ${countWarnings%%.*}<=100 )); then
                echo "CRITICAL - Usage of  ${countWarnings%%.*} % top 5 process --> $name"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/77f04ecb-d788-4121-8728-3718d25149ef/executions
                exit 2
        else
                echo "UNKNOWN - ${countWarnings%%.*}"
                exit 3
fi


