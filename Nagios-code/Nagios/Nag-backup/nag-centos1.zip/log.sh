#!/bin/bash

# mkdir /home/$(whoami)/log
 touch /tmp/data_after1
 touch /tmp/data_before1

 sudo tail -1 /var/log/messages > /tmp/data_after1
 msg=$(tail -1 /tmp/data_after1)
 error=$(tail -1 /tmp/data_after1 | grep -w  'Stopped' | wc -l)

 if cmp -s /tmp/data_after1 /tmp/data_before1
 then
         {
             echo "ok --> NO new logs"
             exit 0
     }
else
        {

        if (( $error>=1 ));then

           {
             echo "CRITICAL-ERROR --> $msg"
             cp /tmp/data_after1 /tmp/data_before1
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/49d2fa96-4429-4d5e-9c28-a6d3e6d3c531/executions
             exit 2
     }

    else
            {

             echo "WARNING --> $msg"
             cp /tmp/data_after1 /tmp/data_before1
             exit 1

            }
    fi
        }


 fi
