#!/bin/bash

countWarnings=$(free -m | awk 'NR==2{printf "%.2f%%\t\t", $3*100/$2 }' | sed 's/%//g')

if (( ${countWarnings%%.*}<=29 )); then
                echo "OK - Usage of   ${countWarnings%%.*} % services in okay  state"
                exit 0
        elif (( 30<=${countWarnings%%.*} && ${countWarnings%%.*}<=49 )); then
                echo "WARNING - Usage of  ${countWarnings%%.*} % services in Warning state"
                exit 1
        elif (( 50<=${countWarnings%%.*} && ${countWarnings%%.*}<=90 )); then
                echo "CRITICAL - Usage of  ${countWarnings%%.*} % services in Warning state"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/8bf59f58-a2c8-4b15-8038-a0fb8560a529/executions
                exit 2
        else
                echo "UNKNOWN - ${countWarnings%%.*}"
                exit 3
fi

