#!/bin/bash

countWarnings=$(top -b -n2 -p 1 | fgrep "Cpu(s)" | tail -1 | awk  '{ print $2 }')

top=$(ps -Ao comm --sort=-pcpu | head -n 6 | tail -5 | awk  'BEGIN { ORS="," } { print }')

pid=$(ps -Ao pid --sort=-pcpu | head -n 6 | awk -F: 'NR==2 {print $1}')

if (( ${countWarnings%%.*}<=60 )); then
                echo "OK - CPU Usage of top5 process : $top --> $pid"
                exit 0

        elif (( 61<=${countWarnings%%.*} && ${countWarnings%%.*}<=70 )); then
                echo "WARNING - CPU Usage top5 process : $top --> $pid "
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                -d "{\"argString\":\"-pid $pid  \"}" \
                http://192.168.2.19:4440/api/16/job/691903e1-3cb7-46cf-b9c2-1e6c8b27ffaf/executions
                exit 1

        elif (( 71<=${countWarnings%%.*} && ${countWarnings%%.*}<=100 )); then
                echo "CRITICAL - CPU Usage top5 process : $top --> $pid "
                exit 2
        else
                echo "UNKNOWN - $top --> $pid"
                exit 3
fi
