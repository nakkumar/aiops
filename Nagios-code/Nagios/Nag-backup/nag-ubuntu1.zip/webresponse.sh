#!/bin/bash

URL=192.168.4.115:80
countWarnings=$(curl -s -w '\nLookup time:\t%{time_namelookup}\nConnect time:\t%{time_connect}\nAppCon time:\t%{time_appconnect}\nRedirect time:\t%{time_redirect}\nPreXfer time:\t%{time_pretransfer}\nStartXfer time:\t%{time_starttransfer}\n\nTotal time:\t%{time_total}\n' -o /dev/null http://$URL | grep -i 'Total time' | awk '{print $3}')

if (( ${countWarnings%%.*}<10 )); then
                echo "OK - Usage of   ${countWarnings%%.*} % services in okay  state"
                exit 0
        elif (( 11<=${countWarnings%%.*} )); then
                echo "CRITICAL - Usage of  ${countWarnings%%.*} % services in Critical state"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: NSUt9PpUTTJ6INH7xcjt09VyMcr8cexX" \
                -d "{\"argString\":\"-servicename $URL \"}" \
#                http://192.168.5.116:4440/api/16/job/6fca6546-7d48-4c3f-be0d-977c594c2f0a/executions
                exit 2
        else
                echo "UNKNOWN - ${countWarnings%%.*}"
                exit 3
fi

