#!/bin/bash

# mkdir /home/$(whoami)/log
 touch /tmp/data_after
 touch /tmp/data_before

 sudo tail -1 /var/log/httpd/error_log > /tmp/data_after
 msg=$(tail -1 /tmp/data_after)
 error=$(tail -1 /tmp/data_after | grep -w down | wc -l)
 if cmp -s /tmp/data_after /tmp/data_before
 then
         {
             echo "ok --> NO new logs"
             exit 0
         }
else
        {
                if (( $error>=1 ));then
                        {
             echo "CRIRICAL-ERROR  --> $msg"
             cp /tmp/data_after /tmp/data_before
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/cbd55c13-73b1-4485-b969-57c861fc2e30/executions
             exit 2
                        }
                else
                        {
             echo "WARNING --> $msg"
             cp /tmp/data_after /tmp/data_before
             exit 1
                        }
                fi
        }


 fi
