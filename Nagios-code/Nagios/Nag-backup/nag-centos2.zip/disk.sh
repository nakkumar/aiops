#!/bin/bash

disk=$(df -H | grep -vE '^Filesystem|tmpfs|cdrom' | awk '{ print $5 }' | tr -d %)

if (( $disk<=60 )); then
                echo "OK - CPU Usage of $disk % Service in Okay State"
                exit 0
        elif (( 61<=$disk && $disk<=70 )); then
                echo "WARNING - CPU Usage of $disk % Service in Warning State"
                exit 1
        elif (( 71<=$disk && $disk<=100 )); then
                echo "CRITICAL - CPU Usage of $disk % Service in Critical State"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/1b9647ab-9199-4e61-b5f5-404939193c88/executions
                exit 2
        else
                echo "UNKNOWN - $disk"
                exit 3
fi

