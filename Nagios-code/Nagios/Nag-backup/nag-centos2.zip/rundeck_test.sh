#!/bin/bash

                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
 http://192.168.2.19:4440/api/16/job/61ee9610-4337-4ceb-90a4-683e8f2a5885/executions
