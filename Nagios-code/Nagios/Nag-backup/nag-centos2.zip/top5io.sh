#!/bin/bash
 iotop -botqqq --iter=10 | awk '{ print $13 }' > /tmp/iodata
sleep 3

name=$(cat /tmp/iodata | head -n 5 | awk  'BEGIN { ORS="," } { print }')

first=$(cat /tmp/iodata | head -n 5 | awk -F: 'NR==1 {print $1,$2}'  | tr -d [,] | tr -s '[:blank:]' ':')
pid=$(ps -eo pid,comm,cmd | grep -w $first | awk -F: 'NR==1 {print $1}' | awk '{ print $1 }')

#echo "first process pid ---> ###############$pid --> $first"

free=$(iostat | awk -F: 'NR==4 {print $1}' | awk '{ print $6 }')
#echo "free io --> $free"
int=${free%.*}
#echo "$int"

total=100

used=$(( $total - $int ))

#echo "used io ---> $used"

if (( $used<=60 )); then
                echo "OK - I/O Usage of $used top5 IO --> $name"
                exit 0
        elif (( 61<=$used && $used<=70 )); then
                echo "WARNING - I/O Usage of $used top5 IO --> $name"
                exit 1
        elif (( 71<=$used )); then
                echo "CRITICAL - I/O Usage of $used top5 IO --> $name"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/17a663ae-e5c4-4778-84e2-72d1ab7b7828/executions
                exit 2
        else
                echo "UNKNOWN - $used top5 IO --> $name"
                exit 3
fi

