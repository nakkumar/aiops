#!/bin/bash

disk=$(df -h | awk '{print $5}' | awk -F: 'NR==4 {print $1}' | tr -d %)

if (( $disk<=70 )); then
                echo "OK - CPU Usage of $disk % Service in Okay State"
                exit 0
        elif (( 71<=$disk && $disk<=80 )); then
                echo "WARNING - CPU Usage of $disk % Service in Warning State"
                exit 1
        elif (( 81<=$disk && $disk<=100 )); then
                echo "CRITICAL - CPU Usage of $disk % Service in Critical State"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/61ee9610-4337-4ceb-90a4-683e8f2a5885/executions
                exit 2
        else
                echo "UNKNOWN - $disk"
                exit 3
fi

