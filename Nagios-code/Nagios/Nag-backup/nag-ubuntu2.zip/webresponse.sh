#!/bin/bash

site=http://192.168.2.24/demo.php
countWarnings=$(curl -s -w 'Testing Website Response Time for :%{url_effective}\n\nLookup Time:\t\t%{time_namelookup}\nConnect Time:\t\t%{time_connect}\nPre-transfer Time:\t%{time_pretransfer}\nStart-transfer Time:\t%{time_starttransfer}\n\nTotal Time:\t\t%{time_total}\n' -o /dev/null $site | grep -i 'Total time' | awk '{print $3}')

if (( ${countWarnings%%.*}<9 )); then
                echo "OK - Usage of   ${countWarnings%%.*} % services in okay  state"
                exit 0
        elif (( 10<=${countWarnings%%.*} )); then
                echo "CRITICAL - Usage of  ${countWarnings%%.*} % services in Critical state"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                -d "{\"argString\":\"-servicename $URL \"}" \
                http://192.168.2.19:4440/api/16/job/66e6a3b2-7035-425b-93a5-6a631ec0eb3f/executions
                exit 2
        else
                echo "UNKNOWN - ${countWarnings%%.*}"
                exit 3
fi

