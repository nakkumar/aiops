#!/bin/bash

countWarnings=$(top -b -n2 -p 1 | fgrep "Cpu(s)" | tail -1 | awk  '{ print $2 }')

if (( ${countWarnings%%.*}<=30 )); then
                echo "OK - CPU Usage of ${countWarnings%%.*} % Service in Okay State"
                exit 0
        elif (( 31<=${countWarnings%%.*} && ${countWarnings%%.*}<=40 )); then
                echo "WARNING - CPU Usage of ${countWarnings%%.*} % Service in Warning State"
                exit 1
        elif (( 41<=${countWarnings%%.*} && ${countWarnings%%.*}<=100 )); then
                echo "CRITICAL - CPU Usage of ${countWarnings%%.*} % Service in Critical State"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                http://192.168.2.19:4440/api/16/job/8b3e6c66-417c-40c9-89a3-9a2d8e4a4440/executions
                exit 2
        else
                echo "UNKNOWN - ${countWarnings%%.*}"
                exit 3
fi
