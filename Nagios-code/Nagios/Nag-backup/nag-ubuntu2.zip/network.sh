#!/bin/bash

#var=$(iftop -Bt -L1 -s1 2> /dev/null | grep "Total send and receive rate:" | awk '{print$7}' > /tmp/networkinfo)
var=$(tail /tmp/networkinfo)

value=${var: -2}


if [[ "$value" == "MB" ]]; then
        total=${var:: -2}
        if (( ${total%%.*}<80 )); then
             echo "WARNING - Network Usage of $total MB Service in Warning State"
             exit 1
        elif (( 80<=${total%%,*} )); then
             echo "CRITICAL -Network Usage of $total MB Service in Critical State"
             curl -D - \
             -X "POST" -H "Accept: application/json" \
             -H "Content-Type: application/json" \
             -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
             http://192.168.2.19:4440/api/16/job/1e7f250b-eb02-4d91-ac78-7baf55004bed/executions
             exit 2
            fi
else
        echo "OK - Network Usage $var Service in Okay State"
        exit 0
fi
