#!/bin/bash
status=dead
for services in apache2 sshd
do
systemctl status $services | grep -i 'running\|dead' | awk '{print $3}' | sed 's/[()]//g' | while read output;
do
        if [ "$output" == "$status" ]; then
                echo "CRITICAL - $services Service is NOT Running"
                curl -D - \
                -X "POST" -H "Accept: application/json" \
                -H "Content-Type: application/json" \
                -H "X-Rundeck-Auth-Token: pIhhJgoqcD3BXkjShNilW0h1KMYNZeZi" \
                -d "{\"argString\":\"-servicename $services  \"}" \
                http://192.168.2.19:4440/api/16/job/72b43874-bfeb-463e-b5ca-be862b2e0c96/executions
                exit 2
        else
                echo "OK - All Services are Running"
                exit 0
        fi
done
done
